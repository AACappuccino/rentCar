$(function() {


	
	var name = $("input[name='userName']");
	var tel = $("input[name='phone']");
	var pass = $("input[name='password']");
	var repass = $("input[name='repassword']");
	var checkbox = $("input[type='checkbox']");

	var nameImg = name.parent().next("td").children("img");
	var telImg = tel.parent().next("td").children("img")
	var passImg = pass.parent().next("td").children("img");
	var repassImg = repass.parent().next("td").children("img")
	var regExp = new RegExp("^(?![0-9]+$)(?![a-zA-Z]+$)[a-zA-Z0-9]{8,16}$");

	name.on('keypress', function() {
		nameImg.css('opacity',1);
		if(name.val() == '') {
			nameImg.attr("src", "img/wrong.png");
		} else {
			nameImg.attr("src", "img/right.png");
		}
	})
	tel.on('keyup', function() {
		telImg.css('opacity',1);
		if(!(/^1[3|4|5|8][0-9]\d{8}$/.test(tel.val()))) {
			telImg.attr("src", "img/wrong.png");
		} else {
			telImg.attr("src", "img/right.png");
		}
	})

	pass.on('keypress', function() {
		passImg.css('opacity',1);
		if(!regExp.test(pass.val()) || pass == "") {
			passImg.attr("src", "img/wrong.png");
		} else {
			passImg.attr("src", "img/right.png")
		}
	})

	repass.on('keypress', function() {
		repassImg.css('opacity',1);
		if(pass.val() == repass.val() && repass.val() != "") {
			repassImg.attr("src", "img/right.png");
		} else {
			repassImg.attr("src", "img/wrong.png")
		}
	})

	function matchInfo() {

		if((name.val() != '') && (/^1[3|4|5|8][0-9]\d{8}$/.test(tel.val())) &&
			regExp.test(pass.val()) && (pass.val() == repass.val()) &&
			checkbox.is(":checked")) {
			return true;
		} else {
			return false;
		}
	}

	$("#submit").click(function(){
		if(matchInfo()){
			$.ajax({
				type: "post",
				url: "",
				async: true,
				dataType:"",
				success: function() {
		
				},
				error: function() {
		
				}
			});
		}else{
			$("#errorMessage").html("所填入信息有误，请重新确认").css("color","red");
		}
	})
})