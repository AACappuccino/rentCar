$(function() {

	if($(".incheck li").length <= 8) {
		$(".incheck > a").text() == '';
	} else {
		$(".incheck > a").text() == "更多";
	}

	$(".incheck li:gt(8)").hide();

	$(".incheck > a").click(function() {
		if($(".incheck > a").text() == "收起") {
			$(".incheck li:gt(8)").hide();
			$(".incheck > a").text("更多");
		} else {
			$(".incheck li:gt(8)").show();
			$(".incheck > a").text("收起");
		}
	});

	
	
})


