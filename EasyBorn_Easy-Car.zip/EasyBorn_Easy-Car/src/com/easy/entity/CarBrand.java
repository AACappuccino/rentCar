package com.easy.entity;


public class CarBrand {
	
	
	private String brand;

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	@Override
	public String toString() {
		return "CarBrand [brand=" + brand + "]";
	}

	public CarBrand(String brand) {
		super();
		this.brand = brand;
	}

	public CarBrand() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
