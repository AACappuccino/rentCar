package com.easy.entity;

import java.lang.String;

public class User {
	
	private String name;
	private String phone;
	private String password;
	private int type;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "User [name=" + name + ", phone=" + phone + ", password=" + password + ", type=" + type + "]";
	}
	public User(String name, String phone, String password, int type) {
		super();
		this.name = name;
		this.phone = phone;
		this.password = password;
		this.type = type;
	}
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
