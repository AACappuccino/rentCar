package com.easy.entity;

public class CarLevels {
	
	
	private String levels;

	public String getLevels() {
		return levels;
	}

	public void setLevels(String levels) {
		this.levels = levels;
	}

	@Override
	public String toString() {
		return "CarLevels [levels=" + levels + "]";
	}

	public CarLevels(String levels) {
		super();
		this.levels = levels;
	}

	public CarLevels() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
}
