package com.easy.entity;

public class CarBean {
	private int car_id;
	private String levels;	
	private String type;
	private String brand;	
	private String structure;
	private String output;
	private String geatbox;
	private String seat;
	private String original;
	private String discount;
	private String image;
	public int getCar_id() {
		return car_id;
	}
	public void setCar_id(int car_id) {
		this.car_id = car_id;
	}
	public String getLevels() {
		return levels;
	}
	public void setLevels(String levels) {
		this.levels = levels;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getStructure() {
		return structure;
	}
	public void setStructure(String structure) {
		this.structure = structure;
	}
	public String getOutput() {
		return output;
	}
	public void setOutput(String output) {
		this.output = output;
	}
	public String getGeatbox() {
		return geatbox;
	}
	public void setGeatbox(String geatbox) {
		this.geatbox = geatbox;
	}
	public String getSeat() {
		return seat;
	}
	public void setSeat(String seat) {
		this.seat = seat;
	}
	public String getOriginal() {
		return original;
	}
	public void setOriginal(String original) {
		this.original = original;
	}
	public String getDiscount() {
		return discount;
	}
	public void setDiscount(String discount) {
		this.discount = discount;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	@Override
	public String toString() {
		return "CarBean [car_id=" + car_id + ", levels=" + levels + ", type=" + type + ", brand=" + brand
				+ ", structure=" + structure + ", output=" + output + ", geatbox=" + geatbox + ", seat=" + seat
				+ ", original=" + original + ", discount=" + discount + ", image=" + image + "]";
	}
	public CarBean(int car_id, String levels, String type, String brand, String structure, String output,
			String geatbox, String seat, String original, String discount, String image) {
		super();
		this.car_id = car_id;
		this.levels = levels;
		this.type = type;
		this.brand = brand;
		this.structure = structure;
		this.output = output;
		this.geatbox = geatbox;
		this.seat = seat;
		this.original = original;
		this.discount = discount;
		this.image = image;
	}
	public CarBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
