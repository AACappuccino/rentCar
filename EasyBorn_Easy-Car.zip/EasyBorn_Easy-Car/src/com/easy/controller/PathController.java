package com.easy.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.easy.entity.Car;

@Controller
public class PathController {

	
	@RequestMapping("gologin")
	public String goLogin(){
		return "login";
	}
	@RequestMapping("goindex")
	public String goIndex(){
		System.out.println("进入到goindex");
		return "index";
	}
	@RequestMapping("goadminlogin")
	public String goAdminLogin(){
		System.out.println("进入到adminLogin");
		return "adminLogin";
	}
	
	@RequestMapping("goadminIndex")
	public String goAdminIndex(){
		System.out.println("进入到adminLogin");
		return "adminIndex";
	}
	@RequestMapping("goUpdateCarList")
	public String UpdataCarList(){
		System.out.println("进入到updateCarList");
		return "updateCarList";
	}
	@RequestMapping("goinsertCar")
	public String insertCar(){
		System.out.println("进入到insertCar");
		return "insertCar";
	}
	@RequestMapping("goupdateCar")
	public String updateCar(Model model,Car car){
		System.out.println("车的品牌"+car.getCar_id());
		model.addAttribute("carid", car.getCar_id());
		model.addAttribute("brand", car.getBrand());
		System.out.println("进入到updateCar");
		return "updateCar";
	}
	
}
