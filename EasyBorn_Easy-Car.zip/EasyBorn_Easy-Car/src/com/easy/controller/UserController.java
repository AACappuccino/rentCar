package com.easy.controller;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.easy.entity.Car;
import com.easy.entity.User;
import com.easy.service.UserService;


@Controller

public class UserController {

	@Autowired
	UserService UserService;
	
	@ResponseBody
	@RequestMapping("login")
	public String add(User user,Model model) throws IOException{		
		
		JSONObject jObject = new JSONObject();		
		int temp = 0;
		String string = "鐧诲綍鎴愬姛";
		System.out.println(user.getPhone()+"***"+user.getPassword());
		if((user.getPhone() != null || user.getPhone() != "")
				&& (user.getPassword() != "" || user.getPassword() != null)){			
			User user2 = UserService.selectPass(user.getPhone());						
			if(user2 == null){
				string = "鐢ㄦ埛涓嶅瓨鍦紝璇峰厛娉ㄥ唽鍐嶇櫥褰�";
								
			}else if(!user2.getPassword().equals(user.getPassword())){
				string =  "璐﹀彿涓庡瘑鐮佷笉鍖归厤";
			}else{
				temp = 1;			
			}			
		}else{
			jObject.put("errorMess", "璐﹀彿鎴栧瘑鐮佷笉鑳戒负绌�");
		}
		jObject.put("data", temp);
		jObject.put("mess", string);
		
		return jObject.toString();
	}	
	
	@ResponseBody
	@RequestMapping("index")
	public String index() throws IOException{		
		
		JSONArray jsonArray = JSONArray.fromObject(UserService.selectAllCar());
		return jsonArray.toString();
	}
	
	@ResponseBody
	@RequestMapping("updateCarList")
	public String updateCarList() throws IOException{
		JSONObject data = new JSONObject();
		JSONArray jsonArray = JSONArray.fromObject(UserService.selectAllCar());
		data.put("carlist", jsonArray.toString());
		jsonArray = JSONArray.fromObject(UserService.selectBrand());
		data.put("carbrand",jsonArray.toString());
		
		System.out.println(data.toString());
		return data+"";		
	}
	
	@ResponseBody
	@RequestMapping("searchCar")
	public String searchCar() throws IOException{	
		JSONArray jsonArray = JSONArray.fromObject(UserService.selectAllCar());
		return jsonArray.toString();		
	}
	
	
	@ResponseBody
	@RequestMapping("adminLogin")
	public String adminLogin(User user) throws IOException{
		
		
		JSONObject jObject = new JSONObject();		
		int temp = 0;
		String string = "鐧诲綍鎴愬姛";
	
		if((user.getPhone() != null || user.getPhone() != "")
				&& (user.getPassword() != "" || user.getPassword() != null)){
			
			User user2 = UserService.selectPass(user.getPhone());		
			System.out.println("绠＄悊鍛樻煡璇㈠悗鐨勪俊鎭�--"+user2.getPassword()+"type"+user2.getType());

			if(user2 == null){
				string = "鐢ㄦ埛涓嶅瓨鍦紝璇峰厛娉ㄥ唽鍐嶇櫥褰�";
			}else if(user2.getType() != 1){
				string = "瀵逛笉璧凤紝鎮ㄧ幇鍦ㄨ繕涓嶆槸绠＄悊鍛�";
			}else if(!user2.getPassword().equals(user.getPassword())){
				string =  "璐﹀彿涓庡瘑鐮佷笉鍖归厤";
			}else{		
				temp = 1;	
			}			
		}else{
			string = "璐﹀彿鎴栧瘑鐮佷笉鑳戒负绌�";
		}
		jObject.put("data", temp);
		jObject.put("mess", string);
		
		return jObject.toString();
	}
	
	@RequestMapping("deleteCar")
	public String deleteCar(Car car){
	
		int n = UserService.deleteCar(car);
		return "updateCarList";
	}

	@RequestMapping("updateCar")
	public String updateCar(Car car,@RequestParam("file") MultipartFile file) throws IllegalStateException, IOException{

		if(file.getSize() != 0){
			car.setImage(getNewName(file));
		}
		int n = UserService.updateCar(car);
		return "updateCarList";
	}
	
	@RequestMapping("insertCar")
	public String insertCar(Car car,@RequestParam("file") MultipartFile file) throws IllegalStateException, IOException{		
				
		if(file.getSize() != 0){
			car.setImage(getNewName(file));
		}			
		int n = UserService.insertCar(car);
		return "updateCarList";
	}
	
	public String getNewName(MultipartFile file) throws IllegalStateException, IOException{
		
		String path = "C:/Users/Cappuccino/Desktop/workspace/EasyBorn_Easy-Car/WebContent/img/";
		String fileName = file.getOriginalFilename();
		String bString = fileName.substring(fileName.lastIndexOf("."));
		String newName = UUID.randomUUID() + bString;
		String newFile = path + newName;
		File file2 = new File(newFile);	
		file.transferTo(file2);
		
		return newName;
	}
	
	@ResponseBody
	@RequestMapping("selectByBrand")
	public String selectByBrand(Car car) throws IOException{
		System.out.println(car.getBrand());
		JSONArray jsonArray = JSONArray.fromObject(UserService.selectByBrand(car));
		return jsonArray.toString();		
	}
	
	
	@ResponseBody
	@RequestMapping("selectBL")
	public String selectBL(Car car) throws IOException{
		JSONObject data = new JSONObject();
		JSONArray jsonArray = JSONArray.fromObject(UserService.selectLevels());
		data.put("carlevels", jsonArray.toString());
		jsonArray = JSONArray.fromObject(UserService.selectBrand());
		data.put("carbrand",jsonArray.toString());
		
		System.out.println(data.toString());
		return data+"";			
	}
	
	@ResponseBody
	@RequestMapping("selectLevels")
	public String selectlevels() throws IOException{
		
		JSONArray jsonArray = JSONArray.fromObject(UserService.selectLevels());
		return jsonArray.toString();		
	}
	
}
