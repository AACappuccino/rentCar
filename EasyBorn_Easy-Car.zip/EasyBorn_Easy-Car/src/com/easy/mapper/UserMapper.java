package com.easy.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.easy.entity.Car;
import com.easy.entity.CarBrand;
import com.easy.entity.CarLevels;
import com.easy.entity.User;

public interface UserMapper {

	User selectPass(@Param("phone") String phone);
	List<Car> selectAllCar();
	List<CarBrand> selectBrand();
	List<Car> selectByBrand(Car car);
	int deleteCar(Car car);
	int updateCar(Car car);
	int insertCar(Car car);
	List<CarLevels> selectLevels();
}
