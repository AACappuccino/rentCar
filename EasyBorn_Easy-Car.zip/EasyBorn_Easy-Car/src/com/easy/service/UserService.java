package com.easy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//import org.springframework.stereotype.Controller;
//import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.easy.entity.Car;
import com.easy.entity.CarBrand;
import com.easy.entity.CarLevels;
import com.easy.entity.User;
import com.easy.mapper.UserMapper;



@Service 
//@Controller @Component @Repository

public class UserService {
	
	@Autowired
	UserMapper userMapper;
	
	public User selectPass(String phone){
		 
		return userMapper.selectPass(phone);
	}
	
	public List<Car> selectAllCar(){
		return userMapper.selectAllCar();
	}
	public List<CarBrand> selectBrand(){
		return userMapper.selectBrand();
	}
	
	public List<Car> selectByBrand(Car car){
		return userMapper.selectByBrand(car);
	}
	public int deleteCar(Car car){
		return userMapper.deleteCar(car);
	}
	public int updateCar(Car car){
		return userMapper.updateCar(car);
	}
	public int insertCar(Car car){
		return userMapper.insertCar(car);
	}
	public List<CarLevels> selectLevels(){
		return userMapper.selectLevels();
	}
 }
